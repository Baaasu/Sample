def palindrome_decorator(func):
    def wrapper(number):
        text = str(number)
        return text == text[::-1]
    return wrapper
@palindrome_decorator
def check_palindrome(number):
    return number
n = int(input("Enter number: "))
print(check_palindrome(n))
