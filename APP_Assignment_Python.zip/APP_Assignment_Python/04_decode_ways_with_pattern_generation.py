s = input("Enter digit string: ")
from functools import lru_cache
@lru_cache(None)
def decode(i):
    if i == len(s):
        return [""]
    if s[i] == "0":
        return []
    result = [chr(64 + int(s[i])) + tail for tail in decode(i + 1)]
    if i + 1 < len(s) and 10 <= int(s[i:i + 2]) <= 26:
        result += [chr(64 + int(s[i:i + 2])) + tail for tail in decode(i + 2)]
    return result
answers = decode(0)
print("Total Ways:", len(answers))
print("Decoded Strings:")
print("\n".join(answers) if answers else "None")
