from collections import defaultdict
from itertools import combinations
from functools import reduce
from datetime import date
import random, sys
students = [("Anita", "CSE", 85), ("Rahul", "CSE", 78), ("Priya", "CSE", 92), ("Kiran", "CSE", 80), ("Meena", "AI", 88), ("Arun", "AI", 79), ("Divya", "AI", 91), ("Vikram", "AI", 83), ("Sara", "Data Science", 90), ("Nikhil", "Data Science", 82), ("Asha", "Cyber Security", 87), ("Ravi", "Cyber Security", 75)]
size = int(sys.argv[1]) if len(sys.argv) > 1 else 3
groups = defaultdict(list)
for student in students: groups[student[1]].append(student)
department = next((d for d, group in groups.items() if len(group) >= size), None)
if department is None:
    print("No department has enough students")
else:
    possible = list(combinations(groups[department], size))
    team = random.choice(possible)
    total = reduce(lambda x, y: x + y, (person[2] for person in team), 0)
    print("===== PROJECT TEAM ALLOCATION =====")
    print("Team Size:", size)
    print("Allocation Date:", date.today().strftime("%d-%m-%Y"))
    print("Department:", department)
    print("Selected Team:")
    for i, (name, dept, marks) in enumerate(team, 1): print(f"{i}. {name} - {marks}")
    print("Total Marks:", total)
    print(f"Average Marks: {total / size:.2f}")
