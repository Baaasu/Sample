class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val, self.left, self.right = val, left, right

def invert(root):
    if root:
        root.left, root.right = invert(root.right), invert(root.left)
    return root

root = TreeNode(4, TreeNode(2, TreeNode(1), TreeNode(3)), TreeNode(7, TreeNode(6), TreeNode(9)))
invert(root)
from collections import deque
q, result = deque([root]), []
while q:
    node = q.popleft()
    result.append(node.val if node else None)
    if node:
        q.extend([node.left, node.right])
while result and result[-1] is None:
    result.pop()
print(result)
