m, n = map(int, input("Enter m and n: ").split())
print([x for x in range(m, n + 1) if str(x) == str(x)[::-1]])
