s = input("Enter string: ")
sub = input("Enter substring: ")
start = s.find(sub)
if start == -1:
    raise ValueError("Substring not found")
changed = "".join(chr((ord(ch) - 97 - 1) % 26 + 97) for ch in sub)
print(s[:start] + changed + s[start + len(sub):])
