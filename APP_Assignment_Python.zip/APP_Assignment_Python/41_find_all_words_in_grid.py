grid = [input("Grid row: ").split() for _ in range(int(input("Number of rows: ")))]
words = input("Words separated by spaces: ").split()
rows, cols = len(grid), len(grid[0])
def exists(word):
    def dfs(r, c, i):
        if i == len(word): return True
        if r < 0 or r >= rows or c < 0 or c >= cols or grid[r][c] != word[i]: return False
        ch, grid[r][c] = grid[r][c], "#"
        found = any(dfs(r + dr, c + dc, i + 1) for dr, dc in ((1,0),(-1,0),(0,1),(0,-1)))
        grid[r][c] = ch
        return found
    return any(dfs(r, c, 0) for r in range(rows) for c in range(cols))
print([word for word in words if exists(word)])
