n = int(input("Enter integer: "))
result = 0
for _ in range(32):
    result = (result << 1) | (n & 1)
    n >>= 1
print(result)
