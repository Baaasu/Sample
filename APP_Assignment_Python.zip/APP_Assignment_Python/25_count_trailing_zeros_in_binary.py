n = int(input("Enter positive integer: "))
print((n & -n).bit_length() - 1)
