cards = input("Enter cards separated by spaces: ").split()
total = len(cards)
ace = sum(card[:-1] == "A" for card in cards)
face = sum(card[:-1] in {"J", "Q", "K"} for card in cards)
red = sum(card[-1] in {"H", "D"} for card in cards)
black = sum(card[-1] in {"C", "S"} for card in cards)
counts = {"Ace": ace, "Face": face, "Red": red}
for name, count in counts.items():
    print(f"P({name})={count / total:.3f}")
print("Most Frequent Category:", max(counts, key=counts.get))
print(f"P(Black)={black / total:.3f}")
