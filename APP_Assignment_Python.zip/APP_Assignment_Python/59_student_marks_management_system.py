class InvalidMarksError(Exception):
    pass
while True:
    try:
        name = input("Student name: ").strip()
        assert name, "Student name cannot be empty"
        marks = float(input("Marks: "))
        if not 0 <= marks <= 100:
            raise InvalidMarksError("Marks must be between 0 and 100")
        with open("student_records.txt", "a", encoding="utf-8") as f:
            f.write(f"{name},{marks:g}\n")
        print("Record saved")
    except (ValueError, AssertionError, InvalidMarksError) as error:
        print("Error:", error)
    finally:
        print("Record processing completed")
    if input("Add another record? (y/n): ").lower() != "y":
        break
