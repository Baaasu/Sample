a, b = map(int, input("Enter a and b: ").split())
print(sum(x ** 3 for x in range(a, b + 1)))
