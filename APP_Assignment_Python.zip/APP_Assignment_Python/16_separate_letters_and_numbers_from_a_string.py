s = input("Enter string: ")
letters = "".join(ch for ch in s if ch.isalpha())
digits = "".join(ch for ch in s if ch.isdigit())
print([letters, digits])
