coins = list(map(int, input("Enter coin denominations: ").split()))
amount = int(input("Enter amount: "))
dp = [amount + 1] * (amount + 1)
dp[0] = 0
for value in range(1, amount + 1):
    for coin in coins:
        if coin <= value:
            dp[value] = min(dp[value], dp[value - coin] + 1)
print(dp[amount] if dp[amount] <= amount else -1)
