dims = list(map(int, input("Enter matrix dimensions p0 p1 ... pn: ").split()))
n = len(dims) - 1
dp = [[0] * n for _ in range(n)]
split = [[0] * n for _ in range(n)]
for length in range(2, n + 1):
    for i in range(n - length + 1):
        j = i + length - 1
        dp[i][j] = float("inf")
        for k in range(i, j):
            cost = dp[i][k] + dp[k + 1][j] + dims[i] * dims[k + 1] * dims[j + 1]
            if cost < dp[i][j]:
                dp[i][j], split[i][j] = cost, k
def order(i, j):
    if i == j:
        return f"A{i + 1}"
    k = split[i][j]
    return "(" + order(i, k) + " x " + order(k + 1, j) + ")"
print("Minimum multiplication cost:", dp[0][n - 1])
print("Optimal parenthesization:", order(0, n - 1))
