from collections import Counter
from functools import reduce
from datetime import date
import random
students = {"Tarun": [82, 91, 78], "Karthik": [65, 72, 68], "Chadrika": [91, 95, 89], "Trisha": [76, 81, 79], "Atul": [88, 84, 92]}
averages = {name: sum(marks) / len(marks) for name, marks in students.items()}
for name, avg in averages.items(): print(name, "average:", round(avg, 2))
print("Highest average:", max(averages, key=averages.get))
print("Random student:", random.choice(list(students)))
grades = Counter("A" if avg >= 90 else "B" if avg >= 80 else "C" if avg >= 70 else "D" for avg in averages.values())
print("Grade counts:", grades)
total = reduce(lambda a, b: a + b, (mark for marks in students.values() for mark in marks))
print("Total marks:", total)
print("Date:", date.today())
