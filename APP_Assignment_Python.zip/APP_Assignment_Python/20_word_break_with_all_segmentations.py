s = input("Enter string: ")
words = set(input("Enter dictionary words separated by spaces: ").split())
from functools import lru_cache
@lru_cache(None)
def segment(i):
    if i == len(s):
        return [()]
    result = []
    for j in range(i + 1, len(s) + 1):
        word = s[i:j]
        if word in words:
            result.extend((word,) + rest for rest in segment(j))
    return result
answers = segment(0)
print("Can Segment:", bool(answers))
print("Segmentations:")
print("\n".join(" ".join(x) for x in answers) if answers else "None")
