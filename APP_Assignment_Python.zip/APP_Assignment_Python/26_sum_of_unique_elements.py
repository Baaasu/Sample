from collections import Counter
nums = list(map(int, input("Enter numbers: ").split()))
unique = [x for x, count in Counter(nums).items() if count == 1]
print("Unique Elements:", *unique if unique else ["None"])
print("Sum:", sum(unique))
