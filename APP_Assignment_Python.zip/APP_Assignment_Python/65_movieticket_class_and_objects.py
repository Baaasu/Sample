class MovieTicket:
    def __init__(self, movie_name, theatre, seat_number):
        self.movie_name = movie_name
        self.theatre = theatre
        self.seat_number = seat_number
tickets = [MovieTicket("Movie A", "Theatre 1", "A1"), MovieTicket("Movie B", "Theatre 2", "B5"), MovieTicket("Movie C", "Theatre 3", "C8")]
for ticket in tickets:
    print(ticket.movie_name, ticket.theatre, ticket.seat_number)
