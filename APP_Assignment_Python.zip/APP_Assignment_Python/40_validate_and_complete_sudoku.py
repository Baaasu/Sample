board = [input(f"Row {i + 1}: ").strip().split() for i in range(9)]
valid = True
for i in range(9):
    row = [x for x in board[i] if x != "."]
    col = [board[r][i] for r in range(9) if board[r][i] != "."]
    if len(row) != len(set(row)) or len(col) != len(set(col)):
        valid = False
for r in range(0, 9, 3):
    for c in range(0, 9, 3):
        box = [board[i][j] for i in range(r, r + 3) for j in range(c, c + 3) if board[i][j] != "."]
        if len(box) != len(set(box)):
            valid = False
if not valid:
    print("Invalid Sudoku board")
else:
    def solve():
        for r in range(9):
            for c in range(9):
                if board[r][c] == ".":
                    used = set(board[r]) | {board[i][c] for i in range(9)}
                    used |= {board[i][j] for i in range(r // 3 * 3, r // 3 * 3 + 3) for j in range(c // 3 * 3, c // 3 * 3 + 3)}
                    for x in map(str, range(1, 10)):
                        if x not in used:
                            board[r][c] = x
                            if solve(): return True
                    board[r][c] = "."
                    return False
        return True
    if solve():
        for row in board: print(" ".join(row))
    else:
        print("No solution")
