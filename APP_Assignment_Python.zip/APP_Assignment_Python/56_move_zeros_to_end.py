values = list(map(int, input("Enter integers: ").split()))
nonzero = [x for x in values if x != 0]
zeros = [x for x in values if x == 0]
print(nonzero + zeros)
