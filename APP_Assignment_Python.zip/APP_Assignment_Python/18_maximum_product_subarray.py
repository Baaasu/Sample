nums = list(map(int, input("Enter numbers: ").split()))
current_max = current_min = answer = nums[0]
for x in nums[1:]:
    if x < 0:
        current_max, current_min = current_min, current_max
    current_max = max(x, current_max * x)
    current_min = min(x, current_min * x)
    answer = max(answer, current_max)
print(answer)
