import heapq
lists = eval(input("Enter sorted lists: "))
heap = []
for i, arr in enumerate(lists):
    if arr:
        heapq.heappush(heap, (arr[0], i, 0))
result = []
while heap:
    value, i, j = heapq.heappop(heap)
    result.append(value)
    if j + 1 < len(lists[i]):
        heapq.heappush(heap, (lists[i][j + 1], i, j + 1))
print(result)
