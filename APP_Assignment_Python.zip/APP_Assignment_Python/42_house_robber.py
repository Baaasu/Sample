nums = list(map(int, input("Enter house amounts: ").split()))
prev2 = prev1 = 0
for value in nums:
    prev2, prev1 = prev1, max(prev1, prev2 + value)
print(prev1)
