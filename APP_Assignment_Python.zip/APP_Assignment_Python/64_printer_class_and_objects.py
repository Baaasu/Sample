class Printer:
    def __init__(self, capacity, mode, printer_type):
        self.capacity = capacity
        self.mode = mode
        self.printer_type = printer_type
printer1 = Printer(20, "Color", "Inkjet")
printer2 = Printer(35, "Mono", "Laser")
printer3 = Printer(15, "Color", "Multifunction")
for printer in (printer1, printer2, printer3):
    print(printer.capacity, printer.mode, printer.printer_type, id(printer))
