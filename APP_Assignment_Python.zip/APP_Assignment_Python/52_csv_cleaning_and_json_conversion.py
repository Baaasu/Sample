import csv, json
raw_data = """Name,Age,Salary,Join Date
Alice, 30, 95000, 2015-03-01
Bob, , 60000, 2018-07-15
Charlie, 35, Unknown, 2024-02-01
Diana, 40, 110000, 2021-11-03"""
records = csv.DictReader(raw_data.splitlines())
cleaned_records = []
for row in records:
    row = {key: value.strip() for key, value in row.items()}
    try:
        if not row["Age"] or not row["Salary"] or row["Salary"].lower() == "unknown": continue
        cleaned_records.append({"name": row["Name"], "age": int(row["Age"]), "salary": float(row["Salary"]), "join_date": row["Join Date"]})
    except ValueError:
        continue
with open("cleaned_data.json", "w", encoding="utf-8") as f:
    json.dump(cleaned_records, f, indent=2)
print(json.dumps(cleaned_records, indent=2))
