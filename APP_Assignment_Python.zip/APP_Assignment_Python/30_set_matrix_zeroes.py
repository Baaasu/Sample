matrix = eval(input("Enter matrix: "))
rows = {i for i, row in enumerate(matrix) if 0 in row}
cols = {j for j in range(len(matrix[0])) if any(matrix[i][j] == 0 for i in range(len(matrix)))}
for i in range(len(matrix)):
    for j in range(len(matrix[0])):
        if i in rows or j in cols:
            matrix[i][j] = 0
print(matrix)
