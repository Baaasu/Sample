x = int(input("Enter integer: "))
sign = -1 if x < 0 else 1
value = int(str(abs(x))[::-1]) * sign
print(value if -2**31 <= value <= 2**31 - 1 else 0)
