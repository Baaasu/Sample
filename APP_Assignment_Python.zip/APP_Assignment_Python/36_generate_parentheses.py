n = int(input("Enter number of pairs: "))
result = []
def generate(current, opened, closed):
    if len(current) == 2 * n:
        result.append(current)
        return
    if opened < n:
        generate(current + "(", opened + 1, closed)
    if closed < opened:
        generate(current + ")", opened, closed + 1)
generate("", 0, 0)
print(result)
