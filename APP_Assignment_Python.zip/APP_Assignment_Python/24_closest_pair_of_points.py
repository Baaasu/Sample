import math
points = eval(input("Enter points: "))
best = float("inf")
for i in range(len(points)):
    for j in range(i + 1, len(points)):
        d = math.dist(points[i], points[j])
        best = min(best, d)
print(best)
