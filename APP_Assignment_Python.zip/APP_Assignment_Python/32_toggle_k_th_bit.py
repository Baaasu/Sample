n, k = map(int, input("Enter n and zero-based bit index k: ").split())
print(n ^ (1 << k))
