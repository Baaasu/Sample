def cumulative_average():
    values = []
    def add(number):
        values.append(number)
        return sum(values) / len(values)
    return add
average = cumulative_average()
while True:
    value = input("Enter number (q to quit): ")
    if value.lower() == "q": break
    try: print("Cumulative average:", average(float(value)))
    except ValueError: print("Enter a valid number")
