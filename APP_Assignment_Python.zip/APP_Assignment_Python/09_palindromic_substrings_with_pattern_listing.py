s = input("Enter string: ")
palindromes = []
for center in range(len(s)):
    for left, right in ((center, center), (center, center + 1)):
        while left >= 0 and right < len(s) and s[left] == s[right]:
            palindromes.append(s[left:right + 1])
            left -= 1
            right += 1
print("Total Count:", len(palindromes))
print("Palindromic Substrings:")
print("\n".join(palindromes))
