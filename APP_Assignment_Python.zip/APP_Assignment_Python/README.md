# APP Assignment — Python Solutions

This folder contains 65 standalone Python programs, one for each numbered question in the supplied 51-page assignment PDF.

## Run in VS Code

1. Extract the ZIP file.
2. Open the `APP_Assignment_Python` folder in VS Code.
3. Open a terminal in VS Code.
4. Run a program with `python 01_single_number.py` (replace the filename with the question you want).

Most programs use only the Python standard library. Question 60 uses NumPy. Install it with:

```bash
python -m pip install numpy
```

Some programs use sample data or a simple interactive input format where the PDF does not specify a precise console format. For matrix/list inputs, enter valid Python list syntax such as `[[1, 2], [3, 4]]`.

Question 61 does not specify interest rates in the PDF, so the program uses clearly illustrative rates. Replace those rates with the rates supplied by your instructor or institution.

Question 63 intentionally includes `breakpoint()` to demonstrate debugging. Type `c` in the debugger prompt to continue, or remove that line if you do not want the pause.

All code files are separate and contain no explanatory code comments.
