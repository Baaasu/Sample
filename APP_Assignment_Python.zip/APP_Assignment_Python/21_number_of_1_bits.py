n = int(input("Enter positive integer: "))
print(n.bit_count())
