import numpy as np
readings = np.array([10, 20, 30, 40, 50])
print("Original array:", readings)
try:
    position = int(input("Insertion position: "))
    raw = input("New integer reading: ")
    if not raw.isdigit():
        raise ValueError("Only non-negative integer digits are accepted")
    if position < 0 or position > len(readings):
        raise IndexError("Insertion position is invalid")
    readings = np.insert(readings, position, int(raw))
    print("Updated array:", readings)
except (ValueError, IndexError) as error:
    print("Error:", error)
finally:
    print("Insertion operation completed")
