n = list(map(int, input("Enter numbers separated by spaces: ").split()))
result = 0
for num in n:
    result ^= num
print(result)
