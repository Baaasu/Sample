n = int(input("Enter number: "))
seen = set()
while n != 1 and n not in seen:
    seen.add(n)
    n = sum(int(ch) ** 2 for ch in str(n))
print(n == 1)
