nums = list(map(int, input("Enter numbers: ").split()))
def odd_sum(values):
    return sum(x for x in values if x % 2)
print("Function parameter:", odd_sum(nums))
print("List comprehension:", sum([x for x in nums if x % 2]))
print("User-defined function:", odd_sum(nums))
