s = input("Enter string: ")
chars = input("Characters to remove: ")
print("".join(ch for ch in s if ch not in set(chars)))
