maze = eval(input("Enter maze matrix: "))
n = len(maze)
path = [[0] * n for _ in range(n)]
visited = [[False] * n for _ in range(n)]
def solve(r, c):
    if r < 0 or c < 0 or r >= n or c >= n or maze[r][c] == 0 or visited[r][c]:
        return False
    path[r][c] = 1
    visited[r][c] = True
    if (r, c) == (n - 1, n - 1): return True
    for dr, dc in ((1, 0), (0, 1), (-1, 0), (0, -1)):
        if solve(r + dr, c + dc): return True
    path[r][c] = 0
    visited[r][c] = False
    return False
if maze[0][0] and maze[-1][-1] and solve(0, 0):
    print("Solution Path:")
    for row in path: print("".join(map(str, row)))
else:
    print("No solution exists")
