n = int(input("Enter number of steps: "))
patterns = []
def climb(remaining, path):
    if remaining == 0:
        patterns.append(path)
        return
    if remaining >= 1: climb(remaining - 1, path + [1])
    if remaining >= 2: climb(remaining - 2, path + [2])
climb(n, [])
print("Total ways:", len(patterns))
for p in patterns: print(p)
