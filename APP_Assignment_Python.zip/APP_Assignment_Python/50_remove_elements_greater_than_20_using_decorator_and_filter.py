def filter_decorator(func):
    def wrapper(values):
        return func(values)
    return wrapper
@filter_decorator
def remove_greater_than_20(values):
    return list(filter(lambda x: x <= 20, values))
nums = list(map(int, input("Enter numbers: ").split()))
print(remove_greater_than_20(nums))
