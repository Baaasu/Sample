n = int(input("Number of vertices: "))
edges = eval(input("Enter undirected edges as [[u,v], ...]: "))
from collections import defaultdict
degree = [0] * n
graph = defaultdict(list)
for u, v in edges:
    graph[u].append(v); graph[v].append(u)
    degree[u] += 1; degree[v] += 1
odd = [i for i, d in enumerate(degree) if d % 2]
nonzero = [i for i, d in enumerate(degree) if d]
if len(odd) not in (0, 2):
    print("No Euler path")
elif nonzero:
    seen, stack = set(), [nonzero[0]]
    while stack:
        u = stack.pop()
        if u not in seen:
            seen.add(u); stack.extend(graph[u])
    if any(v not in seen for v in nonzero):
        print("No Euler path")
    else:
        adj = {u: graph[u][:] for u in range(n)}
        path, stack = [], [odd[0] if odd else nonzero[0]]
        while stack:
            u = stack[-1]
            if adj[u]:
                v = adj[u].pop()
                adj[v].remove(u)
                stack.append(v)
            else:
                path.append(stack.pop())
        print("Euler path:", path[::-1])
else:
    print("Euler path:", [])
