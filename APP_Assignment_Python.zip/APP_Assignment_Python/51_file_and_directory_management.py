import os, time
root = "task1/task2/task3"
os.makedirs(root, exist_ok=True)
print("Current Working Directory:", os.getcwd())
print("Byte String Format:", os.fsencode(os.getcwd()))
file_path = os.path.join(root, "sample.py")
with open(file_path, "w", encoding="utf-8") as f: f.write("print('Hello from sample.py')\n")
print("Directory exists:", os.path.isdir(root))
total_size = 0
for directory, folders, files in os.walk("task1"):
    for name in files: total_size += os.path.getsize(os.path.join(directory, name))
print("Total size:", total_size, "bytes")
print("Access time:", time.ctime(os.path.getatime(file_path)))
print("Last modified time:", time.ctime(os.path.getmtime(file_path)))
print("Directory contents:", os.listdir(root))
