heights = list(map(int, input("Enter heights: ").split()))
left, right = 0, len(heights) - 1
best = 0
while left < right:
    best = max(best, (right - left) * min(heights[left], heights[right]))
    if heights[left] < heights[right]:
        left += 1
    else:
        right -= 1
print(best)
