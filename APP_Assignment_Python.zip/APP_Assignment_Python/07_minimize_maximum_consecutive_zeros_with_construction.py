from itertools import combinations
L, K = map(int, input("Enter L and K: ").split())
best = L
optimal = []
print("Possible Strings:")
for positions in combinations(range(L), K):
    ones = set(positions)
    s = "".join("1" if i in ones else "0" for i in range(L))
    longest = max((len(part) for part in s.split("1")), default=0)
    print(f"{s} -> max zeros = {longest}")
    if longest < best:
        best, optimal = longest, [s]
    elif longest == best:
        optimal.append(s)
print("Optimal Arrangement(s):", ", ".join(optimal))
print("Minimum Longest Zero Block:", best)
