skills = input("Required skills: ").split()
n = int(input("Number of candidates: "))
people = [set(input(f"Candidate {i} skills: ").split()) for i in range(n)]
skill_index = {skill: i for i, skill in enumerate(skills)}
masks = []
for person in people:
    mask = 0
    for skill in person:
        if skill in skill_index:
            mask |= 1 << skill_index[skill]
    masks.append(mask)
full = (1 << len(skills)) - 1
dp = {0: []}
for i, mask in enumerate(masks):
    for covered, team in list(dp.items()):
        new = covered | mask
        if new not in dp or len(team) + 1 < len(dp[new]):
            dp[new] = team + [i]
print(*dp[full])
