import random
guess = input("Predict heads or tails: ").strip().lower()
if guess not in {"heads", "tails"}:
    raise ValueError("Enter heads or tails")
toss = random.choice(["heads", "tails"])
result = toss == guess
breakpoint()
print("Toss:", toss)
print("Your guess:", guess)
print("Correct prediction:", result)
