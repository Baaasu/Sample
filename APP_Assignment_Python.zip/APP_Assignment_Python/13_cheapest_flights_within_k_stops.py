n = int(input("Number of cities: "))
flights = eval(input("Enter flights as [[from,to,cost], ...]: "))
src, dst, k = map(int, input("Enter src dst k: ").split())
prices = [float("inf")] * n
prices[src] = 0
for _ in range(k + 1):
    temp = prices[:]
    for a, b, cost in flights:
        if prices[a] != float("inf"):
            temp[b] = min(temp[b], prices[a] + cost)
    prices = temp
print(prices[dst] if prices[dst] != float("inf") else -1)
