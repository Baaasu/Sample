s = input("Enter lowercase string: ")
visited = [False] * 26
left = best = 0
for right, ch in enumerate(s):
    index = ord(ch) - 97
    while visited[index]:
        visited[ord(s[left]) - 97] = False
        left += 1
    visited[index] = True
    best = max(best, right - left + 1)
print("Length of the longest unique substring:", best)
