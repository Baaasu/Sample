def calculate_interest(metal, purity, amount, tenure):
    rates = {"gold": {18: 9.0, 22: 8.0, 24: 7.0}, "silver": {925: 11.0, 950: 10.5, 999: 10.0}, "platinum": {900: 9.5, 950: 9.0, 999: 8.5}}
    metal = metal.lower()
    if metal not in rates or purity not in rates[metal]:
        raise ValueError("Unsupported metal type or purity")
    rate = rates[metal][purity]
    return amount * rate * tenure / 100
try:
    metal = input("Metal (gold/silver/platinum): ")
    purity = int(input("Purity: "))
    amount = float(input("Loan amount: "))
    tenure = float(input("Tenure in years: "))
    interest = calculate_interest(metal, purity, amount, tenure)
except TypeError as error:
    print("Missing argument:", error)
except ValueError as error:
    print("Invalid input:", error)
else:
    print("Simple interest:", interest)
finally:
    print("Loan calculation completed")
