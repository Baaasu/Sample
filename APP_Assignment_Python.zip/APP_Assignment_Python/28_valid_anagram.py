s = input("Enter first string: ")
t = input("Enter second string: ")
print(sorted(s) == sorted(t))
