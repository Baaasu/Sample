x1, y1, x2, y2 = map(float, input("Enter x1 y1 x2 y2: ").split())
print(((x1 + x2) / 2, (y1 + y2) / 2))
